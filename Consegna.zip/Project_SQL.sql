CREATE DATABASE ToysGroup;
USE ToysGroup;


CREATE TABLE Category(
Product_categoryID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
Category_Name VARCHAR (50)
);

CREATE TABLE Product(
ProductID INT NOT NULL  PRIMARY KEY,        
Product_Name VARCHAR (25),
Product_categoryID INT,
FOREIGN KEY (Product_categoryID) REFERENCES Category(Product_categoryID)
);

CREATE TABLE Region(
RegionID INT NOT NULL PRIMARY KEY, 
Region_Name varchar (50)
);

CREATE TABLE State(
StateID INT NOT NULL  PRIMARY KEY,
State_Name varchar (50),
RegionID INT,
FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

CREATE TABLE Sales( 
SalesID INT NOT NULL  PRIMARY KEY,
ProductID INT,
StateID INT,
Sales_Date DATE,
Quantity int,
Unit_Price DECIMAL(10,2),
FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
FOREIGN KEY (StateID) REFERENCES State(StateID)
);
DESCRIBE Sales;


INSERT INTO Category(Category_Name)
VALUES ('Bikes'),('Accessories'),('Clothing');
SELECT*
FROM Category;

INSERT INTO Product(ProductID,Product_Name,Product_categoryID) 
VALUES
(101,'Bikes-100', 1),
(102,'Microphone', 2),
(103,'Bikes-Buzz', 1),
(201,'Glove L', 3),
(202,'Bike Gloovo M', 1),
(203,'Helmet Pro', 3),
(301,'Waterbottle_Toy',2),
(302,'Stickers', 2),
(303,'T-shirt_Bikes_Toy', 3);
SELECT*
FROM Product;

INSERT INTO Region(RegionID,Region_Name) 
VALUES
(240,'North_Europe'),
(250,'West_Europe'),
(260,'Middle_East'),
(270,'Asia');
SELECT*
FROM Region;

INSERT INTO State (StateID,State_Name,RegionID) VALUES
(41, 'Norway', 240),
(51, 'Germany', 250),
(61, 'Egypt', 260),
(71, 'Singapore', 270);
SELECT*
FROM State;

INSERT INTO Sales (SalesID,ProductID,StateID,Sales_Date,Quantity,Unit_Price)
 VALUES
(1001,101,41,'2024-01-03', 40, 250.00),
(1002,101,41,'2024-06-05', 29, 20.00),
(1003,103,51,'2024-05-01', 25, 350.50),
(1004,303,51, '2025-07-09', 30, 29.55),
(1005,302,71,'2025-08-15', 44, 345.72),
(1006,301,61,'2025-06-10', 75, 200.00),
(1007,202,51,'2024-09-20', 80, 50.00),
(1008,202,71,'2025-02-25', 50, 75.80),
(1009,202,41,'2025-03-04', 50, 75.80);

SELECT*
FROM Sales;
DELETE FROM Sales WHERE SalesID=4001;
INSERT INTO Sales (SalesID,ProductID,StateID,Sales_Date,Quantity,Unit_Price)
 VALUES(4001,101,41,'2025-09-01',100,250);

/*Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l’univocità 
dei valori di ciascuna PK (una query per tabella implementata).*/
SELECT DISTINCT ProductID FROM Product;
SELECT DISTINCT Product_categoryID FROM Category;
SELECT DISTINCT RegionID FROM Region;
SELECT DISTINCT StateID FROM State;
SELECT DISTINCT SalesID FROM Sales;
-- OR
SELECT ProductID, COUNT(*) AS Occorrenze FROM Product GROUP BY ProductID HAVING COUNT(*) > 1;
SELECT Product_categoryID, COUNT(*) AS Occorrenze FROM Category GROUP BY Product_categoryID HAVING COUNT(*) > 1;
SELECT RegionID, COUNT(*) AS Occorrenze FROM Region GROUP BY RegionID HAVING COUNT(*) > 1;
SELECT StateID, COUNT(*) AS Occorrenze FROM State GROUP BY StateID HAVING COUNT(*) > 1;
SELECT SalesID, COUNT(*) AS Occorrenze FROM Sales GROUP BY SalesID HAVING COUNT(*) > 1;
/*Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto,
 la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato 
 in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)*/
 SELECT 
 S.SalesID AS CODICE_DOCUMENTO,
 S.Sales_Date AS DATA_VENDITA,
 P.Product_Name,
 CAT.Category_Name,
 ST.State_Name,
 RG.Region_Name,
 CASE 
 WHEN DATEDIFF(CURDATE(),S.Sales_Date) > 180 THEN TRUE
 ELSE FALSE 
 END AS MORE_180_DAYS
 FROM Sales AS S JOIN Product AS P ON S.ProductID=P.ProductID
 JOIN Category AS CAT ON P.Product_categoryID=CAT.Product_categoryID
 JOIN State AS ST ON S.StateID=ST.StateID
 JOIN Region AS RG ON ST.RegionID=RG.RegionID;
 
 /*Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate 
 nell’ultimo anno censito. (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano)
 Nel result set devono comparire solo il codice prodotto e il totale venduto*/
-- LAST YEAR
SELECT max(year(Sales_Date))AS LAST_YEAR
FROM Sales;
-- > AVG QUANTITY
SET @AVG_Quantity := (
SELECT AVG(Quantity)
FROM Sales
);

SELECT P.ProductID,
P.Product_Name,
SUM(S.Quantity) AS TOTALE_Venduto
FROM Product AS P JOIN Sales AS S ON P.ProductID=S.ProductID
WHERE year(Sales_Date)= '2025'
GROUP BY ProductID
HAVING SUM(S.Quantity)>@AVG_Quantity;

-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno
SELECT P.Product_Name, 
YEAR (S.Sales_Date) AS Sales_Year,
SUM(S.Quantity*S.Unit_Price) AS TOTAL_FATTURATO
FROM Product AS P JOIN Sales AS S ON P.ProductID=S.ProductID
GROUP BY P.Product_Name,S.Sales_Date
ORDER BY Sales_Year, TOTAL_FATTURATO;

-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
SELECT ST.State_Name, 
YEAR (S.Sales_Date) AS Sales_Year,
SUM(S.Quantity*S.Unit_Price) AS TOTAL_FATTURATO
FROM State AS ST JOIN Sales AS S ON ST.StateID=S.StateID
GROUP BY ST.State_Name,S.Sales_Date
ORDER BY Sales_Year, TOTAL_FATTURATO DESC;

-- qual è la categoria di articoli maggiormente richiesta dal mercato
SELECT CAT.Category_Name,
SUM(S.Quantity) AS TOTAL_FATTURATO
FROM Sales AS S JOIN Product AS P ON S.ProductID=S.ProductID
JOIN Category AS CAT ON P.Product_categoryID=CAT.Product_categoryID
GROUP BY CAT.Category_Name
ORDER BY TOTAL_FATTURATO DESC
limit 1;

-- Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.

SELECT P.ProductID, P.Product_Name
FROM Product AS P LEFT JOIN Sales AS S ON P.ProductID=S.ProductID
WHERE S.ProductID IS NULL;

SELECT ProductID, Product_Name
FROM Product
WHERE ProductID NOT IN  (SELECT DISTINCT (ProductID) from sales);

/*Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili 
(codice prodotto, nome prodotto, nome categoria)*/
CREATE VIEW CAT_Product AS (
SELECT P.ProductID,
P.Product_Name,
CAT.Category_Name
FROM Product AS P JOIN Category AS CAT 
ON P.Product_categoryID=CAT.Product_categoryID
ORDER BY Category_Name DESC
);
ALTER VIEW 
CAT_Product AS (
SELECT P.ProductID,
P.Product_Name,
CAT.Category_Name
FROM Product AS P JOIN Category AS CAT 
ON P.Product_categoryID=CAT.Product_categoryID
ORDER BY ProductID DESC
);
SELECT*
FROM CAT_Product;

-- Creare una vista per le informazioni geografiche
CREATE VIEW Geografic_INFO AS (
SELECT RG.RegionID,
RG.Region_Name,
ST.StateID,
ST.State_Name
FROM Region AS RG JOIN State AS ST ON RG.RegionID=ST.RegionID
);
SELECT*
FROM Geografic_INFO;